<tr>
    <td>1</td>
    <td><?php echo e($name); ?></td>
</tr><?php /**PATH D:\student Work\hemanshi html\laravel\ajax\ajax_demo\ajax_demo\resources\views/Ajax.blade.php ENDPATH**/ ?>