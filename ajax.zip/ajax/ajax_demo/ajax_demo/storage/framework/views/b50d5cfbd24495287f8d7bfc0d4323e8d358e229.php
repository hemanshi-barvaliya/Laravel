<tr>
    <td>1</td>
    <td><?php echo e($data['name']); ?></td>
    <td><?php echo e($data['email']); ?></td>
    <td><?php echo e($data['password']); ?></td>
</tr>
<?php /**PATH D:\student Work\hemanshi html\laravel\ajax\ajax_demo\ajax_demo\resources\views/ajax.blade.php ENDPATH**/ ?>