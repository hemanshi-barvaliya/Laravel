<tr>
    <td>1</td>
    <td>{{ $data['name'] }}</td>
    <td>{{ $data['email'] }}</td>
    <td>{{ $data['password'] }}</td>
</tr>
