<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(url('/update/' . $list[0]->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <table>
        <tr>
            <td>Name:</td>
            <td><input type="text" name="name" value="<?php echo e($list[0]->name); ?>"></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="email" name="email" value="<?php echo e($list[0]->email); ?>"></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="password" value="<?php echo e($list[0]->password); ?>"></td>
        </tr>
        <tr>
            <td>Hobby:</td>
            <td>
                <input type="checkbox" name="hobby[]" value="cricket"
                <?php echo e(in_array('cricket', explode(',', $list[0]->hobby)) ? 'checked' : ''); ?>> Cricket
                <input type="checkbox" name="hobby[]" value="camping" 
                <?php echo e(in_array('camping', explode(',', $list[0]->hobby)) ? 'checked' : ''); ?>> Camping
                <input type="checkbox" name="hobby[]" value="travelling" 
                <?php echo e(in_array('travelling', explode(',', $list[0]->hobby)) ? 'checked' : ''); ?>> Travelling
            </td>
        </tr>
        <tr>
            <td>Image:</td>
            <td><input type="file" name="image"></td>
        </tr>
        <tr>
            <td><input type="submit" name="submit" value="Submit"></td>
        </tr>
    </table>
    </form>
</body>
</html>
<?php /**PATH D:\student Work\hemanshi html\laravel\exam-prectice\app\resources\views//update.blade.php ENDPATH**/ ?>