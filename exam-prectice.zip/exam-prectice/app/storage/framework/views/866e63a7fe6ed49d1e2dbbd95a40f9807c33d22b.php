<form method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <table>
        <tr>
            <td>Name:</td>
            <td><input type="text" name="name" required></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="email" name="email" required></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="password" required></td>
        </tr>
        <tr>
            <td>Hobby:</td>
            <td>
                <input type="checkbox" name="hobby[]" value="cricket"> Cricket
                <input type="checkbox" name="hobby[]" value="camping"> Camping
                <input type="checkbox" name="hobby[]" value="travelling"> Travelling
            </td>
        </tr>
        <tr>
            <td>Image:</td>
            <td><input type="file" name="image"></td>
        </tr>
        <tr>
            <td><input type="submit" value="Submit"></td>
        </tr>
    </table>
    
    <table>
        <tr>
            <td>NO</td>
            <td>NAME</td>
            <td>EMAIL</td>
            <td>PASSWORD</td>
            <td>HOBBY</td>
            <td>IMAGE</td>
            <td>UPDATE</td>
            <td>DELETE</td>
        </tr>
        <?php $cnt=1; ?>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cnt++); ?></td>
            <td><?php echo e($req->name); ?></td>
            <td><?php echo e($req->email); ?></td>
            <td><?php echo e($req->password); ?></td>
            <td><?php echo e(implode(', ', explode(',', $req->hobby))); ?></td>
            <td><img src="<?php echo e(asset('images/' .$req->image)); ?>" alt="image" height="100px" width="100px"></td>
            <td><a href="<?php echo e(url('/update/' .$req->id)); ?>">UPDATE</a></td>
            <td><a href="<?php echo e(url('/delete/' .$req->id)); ?>">Delete</a></td>
           
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</form>
<?php /**PATH D:\student Work\hemanshi html\laravel\exam-prectice\app\resources\views/welcome.blade.php ENDPATH**/ ?>